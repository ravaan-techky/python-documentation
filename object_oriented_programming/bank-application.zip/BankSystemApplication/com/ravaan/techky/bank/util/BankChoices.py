from com.ravaan.techky.bank.dto.AccountInfo import AccountInfo;
from com.ravaan.techky.bank.repository.AccountRepository import AccountRepository

def selectBankService():
    '''
    Method to select bank services from 1 to 5 menu options
    1 - Open Account
    2 - Show Balance
    3 - Withdraw Amount
    4 - Deposite Amount
    5 - Exit
    :return:
    '''
    choice = showBankChoice()
    if choice == 0:
        showAllAccounts()
    elif choice == 1:
        openAccount()
    elif choice == 2:
        showBalance()
    elif choice == 3:
        withdrawAmount()
    elif choice == 4:
        depositeAmount()
    else:
        exit(0)

def showAllAccounts():
    '''
    Method to show all account information
    :return:
    '''
    if len(AccountRepository().accounts) > 0:
        print("============== Account Information Available ================")
        for accountInfo in AccountRepository().accounts:
            print(accountInfo)
    else:
        print("============== No Account Information Available ================")

def openAccount():
    '''
    Method to open account
    :return:
    '''
    print('Enter Account Holder Information')
    name = input('Name -')
    address = input('Address -')
    phone = input('Phone -')
    accountInfo = AccountInfo(name, address, phone)
    AccountRepository().add(accountInfo)
    print(f'Account created successful with account id {accountInfo.accountId}')

def fetchAccountDetails():
    '''
    Method to fetch account details
    :return:
    '''
    accountInformation = None
    accountFound = False
    while True:
        accountIdStr = input('Please enter valid account id. ')
        accountId = -1
        if accountIdStr.upper() == 'Q':
            break;
        elif not accountIdStr.isdigit():
            print('Please enter valid account id')
        else:
            accountId = int(accountIdStr)

        for accountInfo in AccountRepository.accounts:
            if accountInfo.accountId == accountId:
                accountFound = True
                accountInformation = accountInfo
                break;

        if accountFound == True:
            break;
        else:
            print('Please enter valid account id OR Press q to exit.')
    return accountInformation

def showBalance():
    '''
    Method to show account balance
    :return:
    '''
    accountInfo = fetchAccountDetails();
    if type(accountInfo) != None:
        print(f'Account Balance is ${accountInfo.balance}')

def withdrawAmount():
    '''
    Method to withdraw amount
    :return:
    '''
    accountInfo = fetchAccountDetails();
    if type(accountInfo) != None:
        if accountInfo.balance <= 0:
            print('Account does not have any balance!!!')
            return None

        while True:
            withdrawAmtStr = input('Enter Withdraw Amount - ')
            if not withdrawAmtStr.isdigit():
                print('Enter valid Withdraw amount!!!')
            else:
                if accountInfo.balance - float(withdrawAmtStr) < 0 :
                    print('Please enter less amount than available amount!!!')
                else:
                    accountInfo.balance -= float(withdrawAmtStr)
                    print(f'Remaining Account Balance is ${accountInfo.balance}')
                    print('Amount Withdraw...')
                    break
    pass

def depositeAmount():
    '''
    Method to deposite amount
    :return:
    '''
    accountInfo = fetchAccountDetails();
    if type(accountInfo) != None:
        while True:
            depositeAmtStr = input('Enter Deposite Amount - ')
            if not depositeAmtStr.isdigit():
                print('Enter valid deposite amount!!!')
            else:
                accountInfo.balance += float(depositeAmtStr)
                print(f'New Account Balance is ${accountInfo.balance}')
                print('Amount Deposited...')
                break

def showBankChoice():
    '''
    Show Bank Application Choices
    :return:
    '''
    print('Please select below service options, -')
    print('0. Show All Account')
    print('1. Open Account')
    print('2. Show Balance')
    print('3. Withdraw Amount')
    print('4. Deposite Amount')
    print('5. Exit')
    choice = -1

    while choice not in range(0, 6):
        choiceStr = input('Enter your choice - ')
        if choiceStr.isdigit():
            choice = int(choiceStr)
        else:
            print('Please enter valid choice!!!')
            choice = -1
    return choice