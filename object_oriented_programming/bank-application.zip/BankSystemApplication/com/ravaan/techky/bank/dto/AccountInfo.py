from random import randint

class AccountInfo():
    '''
        Class for Account Information
    '''

    def __init__(self, name, address, phone):
        '''
            AccountInfo paramaterized constructor.
        :param name: str
        :param address: str
        :param phone: str
        '''
        self.name = name
        self.address = address
        self.phone = phone
        self.balance = 0.00
        self.accountId = randint(1, 10)

    def __str__(self):
        '''
        printing a instance information.
        :return: str
        '''
        return f'Account ID: {self.accountId}\tName: {self.name}\tAddress: {self.address}\tPhone: {self.phone}'

    def __del__(self):
        '''
            delete instance
        :return: str
        '''
        print(f'Deleting account with name - {self.name}')