class AccountRepository():
    '''
    Account Repository class to store and retrive account information.
    '''

    # Account list
    accounts = []

    def __init__(self):
        '''
        Default constructor
        '''
        pass

    def add(self, accountInformation):
        AccountRepository.accounts.append(accountInformation)